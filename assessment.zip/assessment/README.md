# assessment
Akrur's assessment for BPI
